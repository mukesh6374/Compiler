1.Extract the folder.
2.Put the folder compiler in /var/www/html/
3.please change the permission of Your folder /var/www/ by using cmd: sudo chmod -R 0777 /var/www/ . then It can can run without any interuption .
4.start apache2 using cmd: sudo service apache2 start
5.type to open: localhost/compiler/


steps of making:

1.made a basic forms.
2.downloaded ace.js from its site.
3.embeded it to the form to make a codeeditor with stylish look.
4.Now made a input textarea and output textarea for taking input from users and showing output after execution of C# code.
5.please change the permission of Your folder /var/www/ by using cmd: sudo chmod -R 0777 /var/www/ . then It can can run without any interuption .
6.Now, It is very important part that C# can only be compiled and be executed by mono. 
7.So, Downloaded mono-complete that contains whole packages such as mono-devel ,etc.
8.Now it time to compile program. So, It can be done by writing bash script in terminal.
9. To compile use cmd: mcs mydata.cs ,where .cs is the extension for C-Sharp(C#). It creates mydata.exe that is executable file.
10. In Linux .exe is not run. So to achieve this function mono is used. To produce output from a input file(input.txt)  and to save in a new file(output.txt)use cmd: mono mydata.exe <input.txt>output.txt

11.Used php to run bash script by the function: shell_exec($cmd);
12.user writes code in codeeditor and put input in input area. on compiling user gets output if successfully compiled otherwise get error on output area.\


Hope You will enjoy using it.

Thanking You!

@copyright Mukesh Kumar NIT Jamshedpur.
