<?php

  
   $flag=false;


       /* here if user given input in both codeditor as well as in input area then it allows to follow the others instructions   */   
		      if(isset($_POST['editor']) && isset($_POST['inp']))
		       {
		       	   /* here copying the code to other file called mydata.cs*/
		            $data = $_POST['editor'] . "\n";
					$file=fopen("mydata.cs","w");
					fwrite($file,$data);

                   /* here copying the input to other file called input.txt*/
					$data = $_POST['inp'] . "\n";
					$file=fopen("input.txt","w");
					fwrite($file,$data);
					fclose($file);
		           /* closing the file handing operations*/

		           /* hhere deleting the existing output.txt and mydata.exe from the folder using bash cmd and php */
		            shell_exec('rm -f output.txt');
		            shell_exec('rm -f mydata.exe'); 
		     /* here compiling the code which have been taken from the user*/        
            $query=shell_exec('mcs mydata.cs');

            /* here producing the output from compiled data and compying to other file called output.txt*/
            $output=shell_exec('mono mydata.exe <input.txt>output.txt');
         //echo file_get_contents('output.txt');
                  $flag=true;

                  $code=$_POST['editor'];

                  $input=$_POST['inp'];

			   }
			   else
			   {  /* this part is handled only if user didnot provide code or input or we can say this the default part the the compiler such as default code in the codeEditor and as well as input area*/

			   	  $input="";
			   	 $code='using System;

			namespace printHello
			{

			    class printHello
			       {
			            public static void Main(string[] args)
			                    {
			                        Console.Write("Enter your input here: ");
			                        string userinput = Console.ReadLine();	
			                        Console.Write(userinput);
			                    }
			        }
			}';


			   }
          

?>