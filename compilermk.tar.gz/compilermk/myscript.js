<script src="js/jquery.min.js">   </script> 
<script src="ace-builds-master/src-noconflict/ace.js" type="text/javascript" charset="utf-8"></script>

<script>
    var editor = ace.edit("editor");
    editor.setTheme("ace/theme/monokai");
    editor.getSession().setMode("ace/mode/csharp");
    editor.selection.getCursor();
	editor.getSession().setUseWrapMode(true);

	var textarea = $('textarea[name="editor"]').hide();
	$('form').on('submit',function(){
textarea.val(editor.getSession().getValue());
});
</script>